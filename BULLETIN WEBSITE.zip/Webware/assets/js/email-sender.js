const btnSubmit = document.querySelector("#btnSubmit");
const contactForm = document.querySelector("#contact-form");
const senderName = document.querySelector("#name");
const senderEmail = document.querySelector("#email");
const messageSubject = document.querySelector("#subject");
const messageBody = document.querySelector("#message");

const loading = document.querySelector(".loading");

btnSubmit.addEventListener("click", (e) => {
  e.preventDefault();
  if (
    !senderName.value ||
    !senderEmail.value ||
    !messageSubject.value ||
    !messageBody.value
  ) {
    return displayError("All fields are required");
  }

  if (!validateEmail(senderEmail.value)) {
    return displayError("Please provide valid e-mail");
  }

  sendEmail();
});

const sendEmail = () => {
  const data = {
    sender_email: senderEmail.value,
    sender_name: senderName.value,
    sender_subject: messageSubject.value,
    sender_message: messageBody.value,
    receiver_name: "Cite Department",
  };

  loading.classList.add("d-block");
  disableButton();

  emailjs
    .send("service_2m9a46s", "template_koifncq", data)
    .then((res) => displaySuccess("Thank you for getting in touch!"))
    .then(() => {
      contactForm.reset();
      enableButton();
      loading.classList.remove("d-block");
    });
};

const displayError = (errorMessage) => {
  console.log(errorMessage);
  document.querySelector(".loading").classList.remove("d-block");
  const errorMessageContainer = document.querySelector(".error-message");
  errorMessageContainer.innerHTML = errorMessage;
  errorMessageContainer.classList.add("d-block");
  errorMessageContainer.style.background = "red";

  setTimeout(() => {
    errorMessageContainer.classList.remove("d-block");
  }, 3000);
};

const displaySuccess = (successMessage) => {
  document.querySelector(".loading").classList.remove("d-block");
  const errorMessageContainer = document.querySelector(".error-message");
  errorMessageContainer.innerHTML = successMessage;
  errorMessageContainer.classList.add("d-block");
  errorMessageContainer.style.background = "green";

  setTimeout(() => {
    errorMessageContainer.classList.remove("d-block");
  }, 3000);
};

// disable button while e-mail is sending
const disableButton = () => {
  btnSubmit.disabled = true;
  btnSubmit.style.cursor = "wait";
};

// enable button after sending email
const enableButton = () => {
  btnSubmit.disabled = false;
  btnSubmit.style.cursor = "pointer";
};

const validateEmail = (email) => {
  return email.match(
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  )
    ? true
    : false;
};
