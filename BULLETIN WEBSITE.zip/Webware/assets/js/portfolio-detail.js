import {
  getDatabase,
  ref,
  set,
  child,
  update,
  remove,
  get,
  onValue,
  getStorage,
  sRef,
  uploadBytesResumable,
  getDownloadURL,
} from "./firebase-config.js";

const database = getDatabase();

// portfolio-details.html starts here
const aID = localStorage.getItem("announcementID");

const announcementTitle = document.querySelector("#announcementTitle");
const dateUpdate = document.querySelector("#dateUpdated");
const announcementArticle = document.querySelector("#announcementArticle");
const announcementMessage = document.querySelector("#announcementMessage");
const updatedMessage = document.querySelector("#updatedMessage");

const loadDetails = (data) => {
  const { title, articleURL, dateUpdated, images, message, updateMessage } =
    data;

  announcementTitle.innerHTML = title;
  announcementArticle.innerHTML = articleURL === " " ? "N/A" : articleURL;
  dateUpdate.innerHTML = dateUpdated;
  announcementMessage.innerHTML = message;
  updatedMessage.innerHTML = updateMessage;

  loadImages(images);
};

const swiperContainer = document.querySelector("#photo-slider-container");

const loadImages = (images) => {
  for (let x = 0; x < images.length; x++) {
    const singlePhotoContainer = document.createElement("div");
    singlePhotoContainer.classList.add("swiper-slide");

    const photo = document.createElement("img");
    photo.src = images[x] || "assets/img/portfolio/portfolio-11.png";

    singlePhotoContainer.appendChild(photo);

    swiperContainer.appendChild(singlePhotoContainer);
  }
};

const getAnnouncements = async () => {
  const announcementRef = ref(database, "/Announcements/" + aID);
  try {
    await onValue(
      announcementRef,
      async (snapshot) => {
        loadDetails(snapshot.val());
      },
      {
        onlyOnce: true,
      }
    );
  } catch (error) {
    console.log(error);
  }
};

getAnnouncements();

console.log(aID);
