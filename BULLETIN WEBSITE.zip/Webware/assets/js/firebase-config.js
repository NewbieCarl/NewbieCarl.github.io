const firebaseConfig = {
  apiKey: "AIzaSyB9lkyrVTt20Np74k4S_d5cWZWGLt0rgpY",
  authDomain: "cite-bulletin.firebaseapp.com",
  databaseURL:
    "https://cite-bulletin-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "cite-bulletin",
  storageBucket: "cite-bulletin.appspot.com",
  messagingSenderId: "247833105977",
  appId: "1:247833105977:web:d8933a41f0eeb647bbdfe8",
  measurementId: "G-JXMC6CR6FD",
};

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-analytics.js";
export {
  getStorage,
  ref as sRef,
  uploadBytesResumable,
  getDownloadURL,
} from "https://www.gstatic.com/firebasejs/9.6.10/firebase-storage.js";

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export {
  getDatabase,
  ref,
  set,
  child,
  update,
  remove,
  get,
  onValue,
} from "https://www.gstatic.com/firebasejs/9.6.10/firebase-database.js";
