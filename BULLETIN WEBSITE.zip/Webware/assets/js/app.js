import {
  getDatabase,
  ref,
  set,
  child,
  update,
  remove,
  get,
  onValue,
  getStorage,
  sRef,
  uploadBytesResumable,
  getDownloadURL,
} from "./firebase-config.js";

const database = getDatabase();

const announcementContainer = document.querySelector(
  ".row.portfolio-container"
);

const displayCard = async ({ _uid, title, articleURL, images }) => {
  let height = 445.987; // increment by 445.987 per row
  let left = 0; //increment by 439.987px every item
  let top = 0; //increment by 445.987px every row
  let pos = 1;
  // position: absolute; left: 0px; top: 0px;
  const singleCardContainer = document.createElement("div");
  for (let x = 0; x <= announcementContainer.childElementCount; x++) {
    announcementContainer.style.height = `${height.toString()}px`;
    singleCardContainer.removeAttribute("style");
    singleCardContainer.classList.add(
      "col-lg-4",
      "col-md-6",
      "portfolio-item",
      "filter-app"
    );
    singleCardContainer.style.position = "absolute";
    singleCardContainer.style.left = `${left.toString()}px`;
    singleCardContainer.style.top = `${top.toString()}px`;

    left += 439.987;

    if (pos % 3 === 0) {
      left = 0;
      top += 445.987;
      height += 445.987;
    }
    pos++;
  }

  // singleCardContainer.style.position = "relative";

  const portfolioImgContainer = document.createElement("div");
  portfolioImgContainer.classList.add("portfolio-img");

  const portfolioImg = document.createElement("img");
  portfolioImg.classList.add("img-fluid");
  portfolioImg.src = images[0] || "assets/img/portfolio/portfolio-11.png";
  portfolioImg.alt = "Announcement Image";

  const portfolioInfoContainer = document.createElement("div");
  portfolioInfoContainer.classList.add("portfolio-info");

  const announcementTitle = document.createElement("h4");
  // set title
  announcementTitle.innerHTML = title || "title";

  const announcementArticle = document.createElement("p");
  // set url article
  announcementArticle.innerHTML = !articleURL || "N/A";

  const previewLink = document.createElement("a");
  previewLink.classList.add("portfolio-lightbox", "preview-link");
  previewLink.href = images[0] || "assets/img/portfolio/portfolio-11.png";
  previewLink.setAttribute("data-gallery", "portfolioGallery");

  const previewIcon = document.createElement("i");
  previewIcon.classList.add("bx", "bx-plus");

  previewLink.appendChild(previewIcon);

  const detailLink = document.createElement("a");
  detailLink.classList.add("details-link");
  detailLink.href = "portfolio-details.html";
  detailLink.setAttribute("title", "More Details");

  const detailIcon = document.createElement("i");
  detailIcon.classList.add("bx", "bx-link");
  detailIcon.id = _uid;

  detailLink.appendChild(detailIcon);

  portfolioImgContainer.appendChild(portfolioImg);

  portfolioInfoContainer.appendChild(announcementTitle);
  portfolioInfoContainer.appendChild(announcementArticle);
  portfolioInfoContainer.appendChild(previewLink);
  portfolioInfoContainer.appendChild(detailLink);

  singleCardContainer.appendChild(portfolioImgContainer);
  singleCardContainer.appendChild(portfolioInfoContainer);

  announcementContainer.appendChild(singleCardContainer);

  sendDataToDetail();
};

const sendDataToDetail = () => {
  const detailLinkBtn = document.querySelectorAll(".details-link");

  for (let x = 0; x < detailLinkBtn.length; x++) {
    detailLinkBtn[x].addEventListener("click", (e) => {
      localStorage.setItem("announcementID", e.target.id);
    });
  }
};

const getAnnouncements = async () => {
  let newData = [];
  console.log("pangalawa ito");
  const announcementRef = ref(database, "/Announcements");
  try {
    await onValue(
      announcementRef,
      async (snapshot) => {
        // while (announcementContainer.firstChild) {
        //   announcementContainer.removeChild(announcementContainer.firstChild);
        // }
        await snapshot.forEach((childSnapshot) => {
          // console.log(childSnapshot.val());
          displayCard(childSnapshot.val());
        });
        // console.log(snapshot.val());
        // newData.push(snapshot.val());
      },
      {
        onlyOnce: true,
      }
    );
  } catch (error) {
    console.log(error);
  }

  return newData;
};

const loadData = async () => {
  await getAnnouncements();
};

loadData();
