import {
  getDatabase,
  ref,
  set,
  child,
  update,
  remove,
  get,
  onValue,
  getStorage,
  sRef,
  uploadBytesResumable,
  getDownloadURL,
} from "./firebase-config.js";

const title = document.querySelector("#aTitle");
const articleURL = document.querySelector("#aArticles");
const message = document.querySelector("#aMessage");
const updateMessage = document.querySelector("#aUpdateMessage");
const images = document.querySelector("#aImages");
const uploadProgress = document.querySelector("#uploadProgress");
const btnSubmit = document.querySelector("#btnSubmit");

// database connection
const database = getDatabase();

// storage ref
const storage = getStorage();

// button for adding announcement
btnSubmit.addEventListener("click", (e) => {
  e.preventDefault();
  createAnnouncement();
});

// create announcement
const createAnnouncement = async () => {
  if (
    !title.value ||
    !message.value ||
    !updateMessage.value ||
    !images.files.length
  ) {
    return alert("All fields are required!");
  }

  disableButton();

  for (let x = 0; x < images.files.length; x++) {
    await uploadImages(images.files[x], x);
  }
};

// check if all image uploaded
const isAllImageUploaded = (length1, length2) => {
  return length1 === length2;
};

// upload images and db
let imgArray = [];
const uploadImages = async (imageToUpload, currIndex) => {
  let fileToUpload = imageToUpload;

  let fileName =
    fileToUpload.name.split(".")[0] + "" + new Date().getTime().toString();

  const metaData = {
    contentType: fileToUpload.type,
  };

  const imageRef = sRef(storage, "announcement-images/" + fileName);

  const uploadTask = uploadBytesResumable(imageRef, fileToUpload, metaData);

  uploadTask.on(
    "state_changed",
    (snapshot) => {
      let progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      uploadProgress.innerHTML = "Uploading..." + progress + "%";
    },
    (err) => {
      console.log(err);
    },
    () => {
      getDownloadURL(uploadTask.snapshot.ref)
        .then((url) => {
          imgArray.push(url);
          console.log(images.files.length + " : " + imgArray.length);
          if (isAllImageUploaded(images.files.length, imgArray.length)) {
            uploadAnnouncement(imgArray);
            alert("Announcement Created!");
            title.value = "";
            articleURL.value = "";
            message.value = "";
            updateMessage.value = "";
            images.value = "";
            uploadProgress.innerHTML = "";
            imgArray = [];
            enableButton();
          }
        })
        .catch((err) => console.log(err));
    }
  );
};

const month = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const uploadAnnouncement = (imgURLs) => {
  const key = new Date().getTime().toString();

  const monthNow = month[new Date().getMonth()];
  const day = new Date().getDate();
  const year = new Date().getFullYear();

  const dateToday = `${monthNow} ${day}, ${year}`;

  // insert to db
  const announcementRef = "Announcements/" + key;
  set(ref(database, announcementRef), {
    _uid: key,
    dateUpdated: dateToday,
    title: title.value.trim(),
    articleURL: articleURL.value.trim() || " ",
    message: message.value.trim(),
    updateMessage: updateMessage.value.trim(),
    images: imgURLs,
  });
};
// end of create announcement

// displaying of announcement
const announcementContainer = document.querySelector("#announcement-container");

const createAnnouncementDisplay = (data) => {
  // while (announcementContainer.firstChild) {
  //   announcementContainer.removeChild(announcementContainer.firstChild);
  // }

  const { _uid, title, images } = data;
  const singleCardContainer = document.createElement("div");
  singleCardContainer.classList.add("single-card-container");

  const imgContainer = document.createElement("div");
  imgContainer.classList.add("img-container");

  const imgSrc = document.createElement("img");
  imgSrc.classList.add("img-announcement");
  // display image
  imgSrc.src = images[0];
  imgSrc.alt = "announcement_image";

  const aTitle = document.createElement("h2");
  // display title
  aTitle.textContent = title;

  imgContainer.appendChild(imgSrc);
  imgContainer.appendChild(aTitle);

  const btnContainer = document.createElement("div");
  btnContainer.classList.add("button-container");

  const btnUpdate = document.createElement("a");
  btnUpdate.innerHTML = "Update";
  btnUpdate.classList.add("btn", "btn-primary");
  btnUpdate.setAttribute("data-toggle", "modal");
  btnUpdate.href = "#updateAnnouncementModal";
  // assign uid to btn
  btnUpdate.id = _uid;

  const btnDelete = document.createElement("a");
  btnDelete.innerHTML = "Delete";
  btnDelete.classList.add("btn", "btn-danger");
  // assign uid to btn
  btnDelete.id = _uid;

  btnContainer.appendChild(btnUpdate);
  btnContainer.appendChild(btnDelete);

  singleCardContainer.appendChild(imgContainer);
  singleCardContainer.appendChild(btnContainer);

  announcementContainer.appendChild(singleCardContainer);

  updateData(data);
};

const getAnnouncements = () => {
  const announcementRef = ref(database, "/Announcements");
  onValue(announcementRef, (snapshot) => {
    while (announcementContainer.firstChild) {
      announcementContainer.removeChild(announcementContainer.firstChild);
    }
    snapshot.forEach((childSnapshot) => {
      createAnnouncementDisplay(childSnapshot.val());
    });
  });
};

const getSingleAnnouncement = (id) => {
  const data = [];
  const announcementRef = ref(database, "/Announcements/" + id);
  onValue(
    announcementRef,
    (snapshot) => {
      data.push(snapshot.val());
      return;
    },
    {
      onlyOnce: true,
    }
  );
  return data[0];
};

const newTitle = document.querySelector("#newTitle");
const newArticle = document.querySelector("#newArticle");
const newMessage = document.querySelector("#newMessage");
const newUpdateMessage = document.querySelector("#newUpdateMessage");
const newImages = document.querySelector("#newImages");
const announcementID = document.querySelector("#announcementID");
const btnSaveUpdate = document.querySelector("#btnSaveUpdate");

// updating data
const updateData = () => {
  const btnUpdateData = document.querySelectorAll(".btn.btn-primary");
  const btnDeleteData = document.querySelectorAll(".btn.btn-danger");
  for (let x = 0; x < btnUpdateData.length; x++) {
    btnUpdateData[x].addEventListener("click", (e) => {
      let currentID = e.target.id;
      const { _uid, title, articleURL, message, updateMessage } =
        getSingleAnnouncement(currentID);
      announcementID.innerHTML = _uid;
      newTitle.value = title;
      newArticle.value = articleURL;
      newMessage.value = message;
      newUpdateMessage.value = updateMessage;
    });
  }

  for (let x = 0; x < btnDeleteData.length; x++) {
    btnDeleteData[x].addEventListener("click", (e) => {
      e.preventDefault(e);
      let currentID = e.target.id;
      if (confirm("Delete this Announcement?") == true) {
        deleteData(currentID);
        alert("Announcement Deleted!");
        return;
      }
      return;
    });
  }
};

// delete area
const deleteData = (idtoDelete) => {
  const announcementRef = "Announcements/" + idtoDelete;

  remove(ref(database, announcementRef), {});
};

// update area
btnSaveUpdate.addEventListener("click", (e) => {
  updateAnnouncement();
});

// update announcement
const updateAnnouncement = async () => {
  if (!newTitle.value || !newMessage.value || !newUpdateMessage.value) {
    return alert("All fields are required!");
  }

  if (!newImages.files.length) {
    uploadNewAnnouncement("", announcementID.innerHTML);
    alert("Data Updated!");
    return;
  }

  for (let x = 0; x < newImages.files.length; x++) {
    await uploadNewImages(newImages.files[x], x);
  }
};

// upload images and db
let newImgArray = [];
const uploadNewImages = async (imageToUpload, currIndex) => {
  let fileToUpload = imageToUpload;

  let fileName =
    fileToUpload.name.split(".")[0] + "" + new Date().getTime().toString();

  const metaData = {
    contentType: fileToUpload.type,
  };

  const imageRef = sRef(storage, "announcement-images/" + fileName);

  const uploadTask = uploadBytesResumable(imageRef, fileToUpload, metaData);

  uploadTask.on(
    "state_changed",
    (snapshot) => {
      let progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      uploadProgress.innerHTML = "Uploading..." + progress + "%";
    },
    (err) => {
      console.log(err);
    },
    () => {
      getDownloadURL(uploadTask.snapshot.ref)
        .then((url) => {
          newImgArray.push(url);
          if (isAllImageUploaded(newImages.files.length, newImgArray.length)) {
            uploadNewAnnouncement(newImgArray, announcementID.innerHTML);
            newImages.value = "";
            newImgArray = [];
            alert("Data Updated!");
          }
        })
        .catch((err) => console.log(err));
    }
  );
};

const uploadNewAnnouncement = (imgURLs, idToUpdate) => {
  // insert to db
  const announcementRef = "Announcements/" + idToUpdate;

  const monthNow = month[new Date().getMonth()];
  const day = new Date().getDate();
  const year = new Date().getFullYear();

  const dateToday = `${monthNow} ${day}, ${year}`;

  if (!imgURLs) {
    return update(ref(database, announcementRef), {
      title: newTitle.value.trim(),
      dateUpdated: dateToday,
      articleURL: newArticle.value.trim() || " ",
      message: newMessage.value.trim(),
      updateMessage: newUpdateMessage.value.trim(),
    });
  }
  update(ref(database, announcementRef), {
    title: newTitle.value.trim(),
    dateUpdated: dateToday,
    articleURL: newArticle.value.trim() || " ",
    message: newMessage.value.trim(),
    updateMessage: newUpdateMessage.value.trim(),
    images: imgURLs,
  });
};
// end of create announcement

// invoke display
getAnnouncements();

// for button
const disableButton = () => {
  btnSubmit.disabled = true;
  btnSubmit.style.cursor = "wait";
};

const enableButton = () => {
  btnSubmit.disabled = false;
  btnSubmit.style.cursor = "cursor";
};
